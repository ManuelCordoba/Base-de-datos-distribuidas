/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.bdd.middleware.ws;

import co.edu.usbbog.bdd.middleware.model.bogota.*;
import co.edu.usbbog.bdd.middleware.model.medellin.*;
import co.edu.usbbog.bdd.middleware.controller.sb.bogota.PersonaBogFacadeLocal;
import co.edu.usbbog.bdd.middleware.controller.sb.bogota.TelefonoBogFacadeLocal;
import co.edu.usbbog.bdd.middleware.controller.sb.medellin.PersonaMedFacadeLocal;
import co.edu.usbbog.bdd.middleware.controller.sb.medellin.TelefonoMedFacadeLocal;
import co.edu.usbbog.bdd.middleware.model.medellin.PersonaMed;
import com.google.gson.Gson;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.core.MediaType;
import org.json.JSONObject;

/**
 * REST Web Service
 *
 * @author 305
 */
@Path("mid")
public class MidWS {

    @Context
    private UriInfo context;

    @EJB
    PersonaBogFacadeLocal personaBogotaSB;

    @EJB
    PersonaMedFacadeLocal personaMedellinSB;

    @EJB
    TelefonoBogFacadeLocal TelefonoBogotaSB;

    @EJB
    TelefonoMedFacadeLocal TelefonoMedellinSB;

    /**
     * Creates a new instance of MidWS
     */
    public MidWS() {
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("insertarPersona")
    public String insertarPersona(String jsonStr) {
//        String nombre="";
//        String apellido="";
//        int edad;
//        JSONObject jo = new JSONObject(jsonStr);
//        nombre = jo.getString("nombre");
//        apellido = jo.getString("apellido");
//        edad = jo.getInt("edad");
        try {
            String ciudad = "";

            JSONObject json = new JSONObject(jsonStr);
            ciudad = json.getString("ciudad");
            boolean i;
            i = buscarPersona(jsonStr);
            if (ciudad.equals("Bogota") && i == true) {
                PersonaBog personaBog = new Gson().fromJson(jsonStr, PersonaBog.class);
                personaBogotaSB.create(personaBog);

                return "{\"respuesta\" : \"se registro en " + ciudad + "\"}";
            } else if (ciudad.equals("Medellin") && i == true) {
                PersonaMed personaMed = new Gson().fromJson(jsonStr, PersonaMed.class);
                personaMedellinSB.create(personaMed);
                return "{\"respuesta\" : \"se registro en " + ciudad + "\"}";
            } else {
                return "{\"respuesta\" : \"no se registro\"}";
            }
        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se registro por " + e.getMessage() + "\"}";
        }
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("buscarPersonaPorId")
    public String buscarPersonaPorId(String jsonStr) {
        try {

            JSONObject json = new JSONObject(jsonStr);

            PersonaBog personaBog = buscarPersonaBogota(jsonStr);
            PersonaMed personaMed = buscarPersonaMedellin(jsonStr);
            if (personaBog != null) {
                return "{\"respuesta\" : \"" + personaBog.getId() + personaBog.getApp() + personaBog.getNom() + personaBog.getEdad() + "\"}";
            } else if (personaMed != null) {
                return "{\"respuesta\" : \"" + personaMed.getId() + personaMed.getApp() + personaMed.getNom() + personaMed.getEdad() + "\"}";
            } else {
                return "{\"respuesta\" : \"no se encontró\"}";
            }

        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se encontró por " + e.getMessage() + "\"}";
        }
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("eliminarPersona")
    public String eliminarPersona(String jsonStr) {
        try {

            JSONObject json = new JSONObject(jsonStr);
            
            PersonaBog personaBog = buscarPersonaBogota(jsonStr);
            PersonaMed personaMed = buscarPersonaMedellin(jsonStr);
            if (personaBog!=null) {
                personaBogotaSB.remove(personaBog);
                return "{\"respuesta\" : \"se elimino la persona  en Bogota \"}";
            } else if (personaMed!=null) {
                personaMedellinSB.remove(personaMed);
                return "{\"respuesta\" : \"se elimino la persona en Medellin\"}";
            } else {
                return "{\"respuesta\" : \"no se eliminó , no existe\"}";
            }
        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se registro por " + e.getMessage() + "\"}";
        }

    }
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("ContarPersonas")
    public String ContarPersonas(String jsonStr) {

        try {
      

         JSONObject json = new JSONObject(jsonStr);
            
            PersonaBog personaBog ;
            PersonaMed personaMed ;
            int bogota;
            int medellin;
            int total;
            bogota=personaBogotaSB.count();
            medellin=personaMedellinSB.count();
            total=bogota+medellin;
                
           return "{\"Hay estas personas en medellin y bogota\" : \" " + total + "\"}";
            
            
            
            
            
        
        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se registro por " + e.getMessage() + "\"}";
        }
    }
    
    
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("buscarTodosPersona")
    public String buscarTodosPersona() {
        try {

            

      List<PersonaBog> personasbog = personaBogotaSB.findAll();
      List<PersonaMed> personasmed = personaMedellinSB.findAll();
      String todo = "";
      
      todo=listaToString(personasbog, personasmed);
              
            return "{\"respuesta\" : \"esta es la lista \""
                    + todo+"}";
        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se encontró por " + e.getMessage() + "\"}";
        }
    }

    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("updatePersona")
    public String updatePersona(String jsonStr) {
//        String nombre="";
//        String apellido="";
//        int edad;
//        JSONObject jo = new JSONObject(jsonStr);
//        nombre = jo.getString("nombre");
//        apellido = jo.getString("apellido");
//        edad = jo.getInt("edad");
        try {
            String ciudad = "";

            JSONObject json = new JSONObject(jsonStr);
            ciudad = json.getString("ciudad");
            PersonaBog personaBog = new PersonaBog();
            PersonaMed personaMed = new PersonaMed();
            personaBog = buscarPersonaBogota(jsonStr);
            personaMed = buscarPersonaMedellin(jsonStr);
            TelefonoBog telefonoBog = new Gson().fromJson(jsonStr, TelefonoBog.class);
            TelefonoMed telefonoMed = new Gson().fromJson(jsonStr, TelefonoMed.class);

            switch (ciudad) {
                case "Bogota":

                    if (personaBog == null && personaMed != null) {
                        int inter;

                        inter = json.getInt("id");
                        String lista = "";

                        List<TelefonoMed> listaTelefonoMed = TelefonoMedellinSB.findAll();
                        personaBog = new Gson().fromJson(jsonStr, PersonaBog.class);
                        personaBogotaSB.create(personaBog);
                        TelefonoBog telefonoBogota = new TelefonoBog();
                        TelefonoMed telefonoMedellin = new TelefonoMed();
                        for (int i = 0; i < listaTelefonoMed.size(); i++) {
                            String[] parts = listaTelefonoMed.get(i).getProp().toString().split(" ");

                            if (parts[0].toString().equals(json.getString("id"))) {

                                telefonoBogota.setNum(listaTelefonoMed.get(i).getNum());
                                telefonoBogota.setOper(listaTelefonoMed.get(i).getOper());
                                telefonoBogota.setProp(personaBog);
                                TelefonoBogotaSB.create(telefonoBogota);
                                telefonoMed = TelMed(listaTelefonoMed.get(i).getNum().toString());
                                TelefonoMedellinSB.remove(telefonoMed);

                            }
                        }
                        personaMedellinSB.remove(personaMed);
                        return "{\"respuesta\" : \"Se realizo el cambio de ciudad a bogota \"}";
                    } else {
                        return "{\"respuesta\" : \"Se actualizo normal \"}";

                    }

                case "Medellin":

                    if (personaBog != null && personaMed == null) {
                        int inter;

                        inter = json.getInt("id");
                        String lista = "";

                        List<TelefonoBog> listaTelefonoBog = TelefonoBogotaSB.findAll();
                        personaMed = new Gson().fromJson(jsonStr, PersonaMed.class);
                        personaMedellinSB.create(personaMed);
                        TelefonoBog telefonoBogota = new TelefonoBog();
                        TelefonoMed telefonoMedellin = new TelefonoMed();
                        for (int i = 0; i < listaTelefonoBog.size(); i++) {

                            String[] parts = listaTelefonoBog.get(i).getProp().toString().split(" ");

                            if (parts[0].toString().equals(json.getString("id"))) {
                                System.out.println("entro al if");
                                telefonoMedellin.setNum(listaTelefonoBog.get(i).getNum());
                                telefonoMedellin.setOper(listaTelefonoBog.get(i).getOper());
                                telefonoMedellin.setProp(personaMed);
                                TelefonoMedellinSB.create(telefonoMedellin);
                                telefonoBog = TelBog(listaTelefonoBog.get(i).getNum().toString());
                                TelefonoBogotaSB.remove(telefonoBog);

                            }
                        }
                        personaBogotaSB.remove(personaBog);
                        return "{\"respuesta\" : \"Se realizo el cambio de ciudad a medellin \"}";
                    } else {
                        return "{\"respuesta\" : \"Se actualizo normal en Medellin \"}";

                    }

                case "":
                    if (personaBog != null) {
                        personaBog = new Gson().fromJson(jsonStr, PersonaBog.class);
                        personaBogotaSB.edit(personaBog);
                        return "{\"respuesta\" : \"se edito en  bogota\"}";
                    } else if (personaMed != null) {
                        personaMed = new Gson().fromJson(jsonStr, PersonaMed.class);
                        personaMedellinSB.edit(personaMed);
                        return "{\"respuesta\" : \"se edito  en medellin \"}";
                    } else {
                        return "{\"respuesta\" : \"no existe la persona\"}";
                    }
                default:
                    return "{\"respuesta\" : \"no se encontro y no se edito\"}";
            }
        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se registro por " + e.getMessage() + "\"}";
        }

    }

 
///////////////////////////////////////////////TELEFONOS////////////////////////////////////////////////////
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("insertarTelefono")
    public String insertarTelefono(String jsonStr) {
        try {

            JSONObject json = new JSONObject(jsonStr);

            boolean i;
            boolean j;
            boolean k;
            i = buscarPropTelefonoBog(jsonStr);
            j = buscarPropTelefonoMed(jsonStr);
            k = buscarTelefono(jsonStr);
            if (i == true && j == false && k == true) {
                int inter = json.getInt("prop");
                PersonaBog personaBog = personaBogotaSB.find(inter);
                json.remove("prop");
                jsonStr = json.toString();
                TelefonoBog telefonoBog = new Gson().fromJson(jsonStr, TelefonoBog.class);
                telefonoBog.setProp(personaBog);
                TelefonoBogotaSB.create(telefonoBog);
                return "{\"respuesta\" : \"se registro en Bogota \"}";
            } else if (i == false && j == true && k == true) {
                int inter = json.getInt("prop");
                PersonaMed personaMed = personaMedellinSB.find(inter);
                json.remove("prop");
                jsonStr = json.toString();
                TelefonoMed telefonoMed = new Gson().fromJson(jsonStr, TelefonoMed.class);
                telefonoMed.setProp(personaMed);
                TelefonoMedellinSB.create(telefonoMed);
                return "{\"respuesta\" : \"se registro en Medellin\"}";
            } else {
                return "{\"respuesta\" : \"no se registro\"}";
            }
        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se registro por " + e.getMessage() + "\"}";
        }

    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("eliminarTelefono")
    public String eliminarTelefono(String jsonStr) {
        try {

            JSONObject json = new JSONObject(jsonStr);
            TelefonoBog telefonoBog = buscarTelefonoBog(jsonStr);
            TelefonoMed telefonoMed = buscarTelefonoMed(jsonStr);

            if (telefonoBog!=null) {
                             
                TelefonoBogotaSB.remove(telefonoBog);
                return "{\"respuesta\" : \"se elimino  en Bogota \"}";
            } else if (telefonoMed!=null) {
                TelefonoMedellinSB.remove(telefonoMed);
                return "{\"respuesta\" : \"se elimino en Medellin\"}";
            } else {
                return "{\"respuesta\" : \"no se eliminó , no existe\"}";
            }
        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se registro por " + e.getMessage() + "\"}";
        }

    }
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("buscarTelefonoPorNum")
    public String buscarTelefonoPorNum(String jsonStr)  {
        try {

            JSONObject json = new JSONObject(jsonStr);

            TelefonoBog telefonoBog = buscarTelefonoBog(jsonStr);
            TelefonoMed telefonoMed = buscarTelefonoMed(jsonStr);
            if (telefonoBog != null) {
                return "{\"respuesta\" : \"" + telefonoBog.getNum()+ telefonoBog.getOper()+ telefonoBog.getProp() + "\"}";
            } else if (telefonoMed != null) {
                return "{\"respuesta\" : \"" + telefonoMed.getNum()+ telefonoMed.getOper()+ telefonoMed.getProp() + "\"}";
            } else {
                return "{\"respuesta\" : \"no se encontró\"}";
            }

        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se encontró por " + e.getMessage() + "\"}";
        }
    }

    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("ContarPorTelefonCiudad")
    public String ContarPorTelefonCiudad(String jsonStr)  {
        try {
             String ciudad = "";

            JSONObject json = new JSONObject(jsonStr);
            ciudad = json.getString("ciudad");
    
            if (ciudad.equals("Bogota")) {
            PersonaBog personaBog ;
            int bogota;
            bogota=TelefonoBogotaSB.count();
           return "{\"Hay esta cantidad de numeros en bogota\" : \" " + bogota + "\"}";
            } else if (ciudad.equals("Medellin")) {
            int medellin;            
            medellin=TelefonoMedellinSB.count();
           return "{\"Hay esta cantidad de numeros en bogota\" : \" " + medellin + "\"}";
                
            } else {
                return "{\"respuesta\" : \"no se encontró\"}";
            }

        } catch (EJBException e) {
            return "{\"respuesta\" : \"No se encontró por " + e.getMessage() + "\"}";
        }
    }
    
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("consultaTelxNom")
    public String consultaTelxNom(String jsonStr) {
        
        JSONObject json = new JSONObject(jsonStr);
         String id= json.getString("id");
         
            PersonaBog personaBog = buscarPersonaBogota(jsonStr);
           
             if (personaBog != null) {
                 
                 String lista="";
                 List<TelefonoBog> listaTelefonoBog =TelefonoBogotaSB.findAll();
                 System.out.println(listaTelefonoBog.get(0).getNum());
                 
                     lista=listaBogToString(listaTelefonoBog,id);
                  if(lista != null){
                 return "{"+ lista + "}";
                 
                }else{return "{\"respuesta\" : \"El usuario no tiene telefonos registrados\"}";}
             }else{
                 
                 PersonaMed personaMed = buscarPersonaMedellin(jsonStr);
             
                 if (personaMed != null) {   
                     String lista="";
                 List<TelefonoMed> listaTelefonoMed =TelefonoMedellinSB.findAll();   
                 
                 
                     lista=listaMedToString(listaTelefonoMed,id);
                     if(lista != null){
                 return "{"+ lista + "}";
                 
                }else{return "{\"respuesta\" : \"El usuario no tiene telefonos registrados\"}";}
                 }else{return "{\"respuesta\" : \"El usuario no existe\"}";}
             
             }
    }

 
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("consultaOper")
    public String consultaOper(String jsonStr) {
        
        JSONObject json = new JSONObject(jsonStr);
         String oper= json.getString("oper");
         
        String lista = "";
        List<TelefonoBog> listaTelefonoBog = TelefonoBogotaSB.findAll();
        System.out.println(listaTelefonoBog.get(0).getNum());
        List<TelefonoMed> listaTelefonoMed = TelefonoMedellinSB.findAll();
      
        lista = listaOper(listaTelefonoBog,listaTelefonoMed, oper);
        if(lista==null){
        return "{\"respuesta\" : \"no se encontró\"}";
        }
        return "{" + lista + "}";


                 
             
             
             }
    

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("updateTelefono")
    public String updateTelefono(String jsonStr) {
        Boolean id = false, tel = false;
        Boolean conUB = false, conUM = false, conTVB = false, conTVM = false;
        JSONObject json = new JSONObject(jsonStr);

        //comprueba id del propietario
        id = buscarPerBogota(json.getString("id"));

        if (id) {
            conUB = true;
        } else {

            id = buscarPerMedellin(json.getString("id"));
            if (id) {
                conUM = true;
            }
        }

        //Comprueba si exsiste el tel viejo
        tel = buscarTelBog(json.getString("num"));
        if (tel) {
            conTVB = true;
        } else {
            tel = buscarTelMed(json.getString("num"));
            if (tel) {

                conTVM = true;
            }
        }

        if (conTVB == false && conTVM == false) {
            return "{\"respuesta\" : \"No se encontro el telefono\"}";
        } else {

            if (conUB == false && conUM == false) {
                return "{\"respuesta\" : \"El Usuario no existe\"}";
            } else {

                if (conUB && conTVB) {
                    PersonaBog personaBog = buscarPersonaBogota(jsonStr);
                    TelefonoBog telefonoBog = new TelefonoBog();
                    telefonoBog.setNum(Integer.parseInt(json.getString("num")));
                    telefonoBog.setOper(json.getString("oper"));
                    telefonoBog.setProp(personaBog);
                    TelefonoBogotaSB.edit(telefonoBog);
                    return "{\"respuesta\" : \"se Actualiza normal en Bogota\"}";
                } else {
                    if (conUM && conTVM) {
                        PersonaMed personaMed = buscarPersonaMedellin(jsonStr);
                        TelefonoMed telefonoMed = buscarTelefonoMed(jsonStr);
                        telefonoMed.setNum(Integer.parseInt(json.getString("num")));
                        telefonoMed.setOper(json.getString("oper"));
                        telefonoMed.setProp(personaMed);
                        TelefonoMedellinSB.edit(telefonoMed);
                        return "{\"respuesta\" : \"se Actualiza normal en Medellin\"}";
                    } else {
 
                        if (conUB && conTVM) {
                            PersonaBog personaBog = buscarPersonaBogota(jsonStr);
                            TelefonoBog telefonoBog = new TelefonoBog();
                            
                            TelefonoMed telefonoMed = buscarTelefonoMed(jsonStr);
                            telefonoBog.setNum(Integer.parseInt(json.getString("num")));
                            telefonoBog.setOper(json.getString("oper"));
                            telefonoBog.setProp(personaBog);
                            TelefonoMedellinSB.remove(telefonoMed);
                            TelefonoBogotaSB.create(telefonoBog);

                            return "{\"respuesta\" : \"se inserta en Bogota y se borra en medellin\"}";
                        } else {
                            if (conUM && conTVB) {

                                PersonaMed personaMed = buscarPersonaMedellin(jsonStr);
                                TelefonoMed telefonoNMed = new TelefonoMed();
                                TelefonoBog telefonoBog = buscarTelefonoBog(jsonStr);
                                telefonoNMed.setNum(Integer.parseInt(json.getString("num")));
                                telefonoNMed.setOper(json.getString("oper"));
                                telefonoNMed.setProp(personaMed);
                                TelefonoBogotaSB.remove(telefonoBog);
                                TelefonoMedellinSB.create(telefonoNMed);
                                return "{\"respuesta\" : \"se inserta en Medellin y se borra en bogota\"}";
                            }
                        }
                        return "{\"respuesta\" : \"todo esta bien\"}";
                    }
                }
            }
        }

    }


  
    
  
    
    //////////////////////////////Metodos- complementos////////////////////////////
   public String listaBogToString (List<TelefonoBog> lista, String id){
        String busqueda = "";
        int c=0;
        for (int i = 0; i < lista.size(); i++) {
            String[] parts = lista.get(i).getProp().toString().split(" ");
            if(parts[0].toString().equals(id)){
                   busqueda+= lista.get(i).toString()+"\n";
                   c++;
                         
                     }}
        busqueda+="\n cantidad de Numeros: "+c;
        return busqueda;
        
    }
   
   public boolean buscarPersona(String jsonStr) {
        try {

            int inter;
            JSONObject json = new JSONObject(jsonStr);
            inter = json.getInt("id");
            PersonaBog personaBog;
            PersonaMed personaMed;
            personaBog = personaBogotaSB.find(inter);
            personaMed = personaMedellinSB.find(inter);
            if (personaBog == null && personaMed == null) {
                return true;
            } else {
                return false;
            }

        } catch (EJBException e) {
            return false;
        }
    }

    public PersonaBog buscarPersonaBogota(String jsonStr) {
        try {

            int inter;
            JSONObject json = new JSONObject(jsonStr);
            inter = json.getInt("id");
            PersonaBog personaBog;

            personaBog = personaBogotaSB.find(inter);

            if (personaBog != null) {
                return personaBog;
            } else {
                return null;
            }

        } catch (EJBException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    public PersonaMed buscarPersonaMedellin(String jsonStr) {
        try {

            int inter;
            JSONObject json = new JSONObject(jsonStr);
            inter = json.getInt("id");

            PersonaMed personaMed;

            personaMed = personaMedellinSB.find(inter);
            if (personaMed != null) {
                return personaMed;
            } else {
                return null;
            }

        } catch (EJBException e) {
            return null;
        }
    }

    public boolean buscarPropTelefonoBog(String jsonStr) {

        try {

            int inter;
            JSONObject json = new JSONObject(jsonStr);
            inter = json.getInt("prop");
            PersonaBog personaBog;

            personaBog = personaBogotaSB.find(inter);

            if (personaBog != null) {
                return true;
            } else {
                return false;
            }

        } catch (EJBException e) {
            return false;
        }

    }

    public boolean buscarPropTelefonoMed(String jsonStr) {
        try {

            int inter;
            JSONObject json = new JSONObject(jsonStr);
            inter = json.getInt("prop");

            PersonaMed personaMed;

            personaMed = personaMedellinSB.find(inter);

            if (personaMed != null) {
                return true;
            } else {
                return false;
            }
        } catch (EJBException e) {
            return false;
        }

    }

    public boolean buscarTelefono(String jsonStr) {

        try {

            int celular;
            JSONObject json = new JSONObject(jsonStr);
            celular = json.getInt("num");
            TelefonoBog telefonoBog;
            TelefonoMed telefonoMed;
            telefonoBog = TelefonoBogotaSB.find(celular);
            telefonoMed = TelefonoMedellinSB.find(celular);
            if (telefonoBog == null && telefonoMed == null) {
                return true;
            } else {
                return false;
            }

        } catch (EJBException e) {
            return false;
        }
    }

    public TelefonoBog buscarTelefonoBog(String jsonStr) {

        try {

            int celular;
            JSONObject json = new JSONObject(jsonStr);
            celular = json.getInt("num");
            TelefonoBog telefonoBog;

            telefonoBog = TelefonoBogotaSB.find(celular);

            if (telefonoBog != null) {
                return telefonoBog;
            } else {
                return null;
            }

        } catch (EJBException e) {
             System.out.println(e.getMessage());
            return null;
        }
    }

    public TelefonoMed buscarTelefonoMed(String jsonStr) {

        try {

            int celular;
            JSONObject json = new JSONObject(jsonStr);
            celular = json.getInt("num");
            TelefonoMed telefonoMed;
            telefonoMed = TelefonoMedellinSB.find(celular);
            if (telefonoMed != null) {
                return telefonoMed;
            } else {
                return null;
            }

        } catch (EJBException e) {
            System.out.println(""+e.getMessage());
            return null;
        }
    }
    
    public String listaMedToString (List<TelefonoMed> lista, String id){
        String busqueda = "";
       int c=0;
        for (int i = 0; i < lista.size(); i++) {
         String[] parts = lista.get(i).getProp().toString().split(" ");
            if(parts[0].toString().equals(id)){
                   busqueda+= lista.get(i).toString()+"\n";
                   c++;
                         
                     }}
        busqueda+="\n cantidad de Numeros: "+c;
        return busqueda;
        
    }
    
    
    public String listaToString (List<PersonaBog> listab,List<PersonaMed> listam){
        String busqueda = "";
     
        for (int i = 0; i < listab.size(); i++) {
         busqueda+= listab.get(i).toString() +"\n";}  
        for (int j = 0; j < listam.size(); j++) {
            
        busqueda+= listam.get(j).toString() +" \n";  
 
                         
                     
                 
                         
                     }
 
        return busqueda;
        
    }
    
    public String listaOper (List<TelefonoBog> listab,List<TelefonoMed> listam,String oper){
        String busqueda = "";
     int c=0;
        for (int i = 0; i < listab.size(); i++) {
            if (listab.get(i).getOper().equals(oper)) {
                c++;
            busqueda+= listab.get(i).toString() +"\n";}  }
         
        for (int j = 0; j < listam.size(); j++) {
        if (listam.get(j).getOper().equals(oper)) {
              c++;  
            busqueda+= listam.get(j).toString() +"\n";}  }
           busqueda+="Cantidad de numeros:"+c;       
        return busqueda;
        
    }
    
    public boolean buscarPerBogota(String id) {

        //true = existe    false = no existe/error 
        try {

            int idInt = Integer.parseInt(id);

            PersonaBog personaBog = personaBogotaSB.find(idInt);

            if (personaBog != null) {
                return true;
            } else {
                return false;
            }

        } catch (EJBException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public boolean buscarPerMedellin(String id) {
        try {

            int idInt = Integer.parseInt(id);

            PersonaMed personaMed = personaMedellinSB.find(idInt);
            if (personaMed != null) {
                return true;
            } else {
                return false;
            }

        } catch (EJBException e) {
            System.out.println(e.getMessage());
            return true;
        }
    }

    public boolean buscarTelBog(String tel) {

        try {

            int telInt = Integer.parseInt(tel);
            TelefonoBog telefonoBog = TelefonoBogotaSB.find(telInt);

            if (telefonoBog != null) {
                return true;
            } else {
                return false;
            }

        } catch (EJBException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public boolean buscarTelMed(String tel) {

        try {

            int telInt = Integer.parseInt(tel);
            TelefonoMed telefonoMed = TelefonoMedellinSB.find(telInt);

            if (telefonoMed != null) {
                return true;
            } else {

                return false;
            }

        } catch (EJBException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public String propTelMed(String tel) {

        try {

            int telInt = Integer.parseInt(tel);
            TelefonoMed telefonoMed = TelefonoMedellinSB.find(telInt);

            if (telefonoMed != null) {
                return telefonoMed.getProp().toString();
            } else {

                return null;
            }

        } catch (EJBException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    public String propTelBog(String tel) {

        try {

            int telInt = Integer.parseInt(tel);
            TelefonoBog telefonoBog = TelefonoBogotaSB.find(telInt);

            if (telefonoBog != null) {
                return telefonoBog.getProp().toString();
            } else {

                return null;
            }

        } catch (EJBException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }
    
    public TelefonoBog TelBog(String tel) {

        try {

            int telInt = Integer.parseInt(tel);
            TelefonoBog telefonoBog = TelefonoBogotaSB.find(telInt);

            if (telefonoBog != null) {
                return telefonoBog;
            } else {

                return null;
            }

        } catch (EJBException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }
     
    public TelefonoMed TelMed(String tel) {

        try {

            int telInt = Integer.parseInt(tel);
            TelefonoMed telefonoMed = TelefonoMedellinSB.find(telInt);

            if (telefonoMed != null) {
                return telefonoMed;
            } else {

                return null;
            }

        } catch (EJBException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }
    
}
