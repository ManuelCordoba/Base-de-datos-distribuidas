/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.bdd.middleware.controller.sb.bogota;

import co.edu.usbbog.bdd.middleware.model.bogota.TelefonoBog;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author 305
 */
@Local
public interface TelefonoBogFacadeLocal {

    void create(TelefonoBog telefonoBog);

    void edit(TelefonoBog telefonoBog);

    void remove(TelefonoBog telefonoBog);

    TelefonoBog find(Object id);

    List<TelefonoBog> findAll();

    List<TelefonoBog> findRange(int[] range);

    int count();
    
}
