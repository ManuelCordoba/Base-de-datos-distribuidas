/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.bdd.middleware.controller.sb.bogota;

import co.edu.usbbog.bdd.middleware.model.bogota.PersonaBog;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author 305
 */
@Local
public interface PersonaBogFacadeLocal {

    void create(PersonaBog personaBog);

    void edit(PersonaBog personaBog);

    void remove(PersonaBog personaBog);

    PersonaBog find(Object id);

    List<PersonaBog> findAll();

    List<PersonaBog> findRange(int[] range);

    int count();
    
}
