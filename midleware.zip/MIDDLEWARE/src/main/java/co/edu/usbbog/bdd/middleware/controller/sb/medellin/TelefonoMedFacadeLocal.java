/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.bdd.middleware.controller.sb.medellin;

import co.edu.usbbog.bdd.middleware.model.medellin.TelefonoMed;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author 305
 */
@Local
public interface TelefonoMedFacadeLocal {

    void create(TelefonoMed telefonoMed);

    void edit(TelefonoMed telefonoMed);

    void remove(TelefonoMed telefonoMed);

    TelefonoMed find(Object id);

    List<TelefonoMed> findAll();

    List<TelefonoMed> findRange(int[] range);

    int count();
    
}
