/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.bdd.middleware.controller.sb.medellin;

import co.edu.usbbog.bdd.middleware.model.medellin.PersonaMed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author 305
 */
@Stateless
public class PersonaMedFacade extends AbstractFacade<PersonaMed> implements PersonaMedFacadeLocal {

    @PersistenceContext(unitName = "mid_med_PU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PersonaMedFacade() {
        super(PersonaMed.class);
    }
    
}
