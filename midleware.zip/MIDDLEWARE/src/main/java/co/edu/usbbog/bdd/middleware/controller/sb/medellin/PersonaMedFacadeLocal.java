/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.bdd.middleware.controller.sb.medellin;

import co.edu.usbbog.bdd.middleware.model.medellin.PersonaMed;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author 305
 */
@Local
public interface PersonaMedFacadeLocal {

    void create(PersonaMed personaMed);

    void edit(PersonaMed personaMed);

    void remove(PersonaMed personaMed);

    PersonaMed find(Object id);

    List<PersonaMed> findAll();

    List<PersonaMed> findRange(int[] range);

    int count();
    
}
